module {
  func.func @_lambda__proxy(%arg0: tensor<1x75x!FHE.eint<8>>) -> tensor<1x2x2x!FHE.eint<6>> {
    %0 = "FHELinalg.transpose"(%arg0) {axes = []} : (tensor<1x75x!FHE.eint<8>>) -> tensor<75x1x!FHE.eint<8>>
    %cst = arith.constant dense<"0x000001000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000"> : tensor<16x75xi2>
    %1 = "FHELinalg.matmul_int_eint"(%cst, %0) : (tensor<16x75xi2>, tensor<75x1x!FHE.eint<8>>) -> tensor<16x1x!FHE.eint<8>>
    %c1_i2 = arith.constant 1 : i2
    %from_elements = tensor.from_elements %c1_i2 : tensor<1xi2>
    %2 = "FHELinalg.mul_eint_int"(%1, %from_elements) : (tensor<16x1x!FHE.eint<8>>, tensor<1xi2>) -> tensor<16x1x!FHE.eint<8>>
    %c0_i2 = arith.constant 0 : i2
    %from_elements_0 = tensor.from_elements %c0_i2 : tensor<1xi2>
    %3 = "FHELinalg.add_eint_int"(%2, %from_elements_0) : (tensor<16x1x!FHE.eint<8>>, tensor<1xi2>) -> tensor<16x1x!FHE.eint<8>>
    %cst_1 = arith.constant dense<[[31], [31], [31], [31], [31], [31], [31], [31], [31], [31], [31], [31], [31], [0], [0], [0]]> : tensor<16x1xi6>
    %4 = "FHELinalg.to_signed"(%3) : (tensor<16x1x!FHE.eint<8>>) -> tensor<16x1x!FHE.esint<8>>
    %5 = "FHELinalg.sub_int_eint"(%cst_1, %4) : (tensor<16x1xi6>, tensor<16x1x!FHE.esint<8>>) -> tensor<16x1x!FHE.esint<8>>
    %6 = "FHELinalg.lsb"(%5) : (tensor<16x1x!FHE.esint<8>>) -> tensor<16x1x!FHE.esint<8>>
    %7 = "FHELinalg.sub_eint"(%5, %6) : (tensor<16x1x!FHE.esint<8>>, tensor<16x1x!FHE.esint<8>>) -> tensor<16x1x!FHE.esint<8>>
    %8 = "FHELinalg.reinterpret_precision"(%7) : (tensor<16x1x!FHE.esint<8>>) -> tensor<16x1x!FHE.esint<7>>
    %9 = "FHELinalg.lsb"(%8) : (tensor<16x1x!FHE.esint<7>>) -> tensor<16x1x!FHE.esint<7>>
    %10 = "FHELinalg.sub_eint"(%8, %9) : (tensor<16x1x!FHE.esint<7>>, tensor<16x1x!FHE.esint<7>>) -> tensor<16x1x!FHE.esint<7>>
    %11 = "FHELinalg.reinterpret_precision"(%10) : (tensor<16x1x!FHE.esint<7>>) -> tensor<16x1x!FHE.esint<6>>
    %12 = "FHELinalg.lsb"(%11) : (tensor<16x1x!FHE.esint<6>>) -> tensor<16x1x!FHE.esint<6>>
    %13 = "FHELinalg.sub_eint"(%11, %12) : (tensor<16x1x!FHE.esint<6>>, tensor<16x1x!FHE.esint<6>>) -> tensor<16x1x!FHE.esint<6>>
    %14 = "FHELinalg.reinterpret_precision"(%13) : (tensor<16x1x!FHE.esint<6>>) -> tensor<16x1x!FHE.esint<5>>
    %15 = "FHELinalg.lsb"(%14) : (tensor<16x1x!FHE.esint<5>>) -> tensor<16x1x!FHE.esint<5>>
    %16 = "FHELinalg.sub_eint"(%14, %15) : (tensor<16x1x!FHE.esint<5>>, tensor<16x1x!FHE.esint<5>>) -> tensor<16x1x!FHE.esint<5>>
    %17 = "FHELinalg.reinterpret_precision"(%16) : (tensor<16x1x!FHE.esint<5>>) -> tensor<16x1x!FHE.esint<4>>
    %18 = "FHELinalg.lsb"(%17) : (tensor<16x1x!FHE.esint<4>>) -> tensor<16x1x!FHE.esint<4>>
    %19 = "FHELinalg.sub_eint"(%17, %18) : (tensor<16x1x!FHE.esint<4>>, tensor<16x1x!FHE.esint<4>>) -> tensor<16x1x!FHE.esint<4>>
    %20 = "FHELinalg.reinterpret_precision"(%19) : (tensor<16x1x!FHE.esint<4>>) -> tensor<16x1x!FHE.esint<3>>
    %21 = "FHELinalg.lsb"(%20) : (tensor<16x1x!FHE.esint<3>>) -> tensor<16x1x!FHE.esint<3>>
    %22 = "FHELinalg.sub_eint"(%20, %21) : (tensor<16x1x!FHE.esint<3>>, tensor<16x1x!FHE.esint<3>>) -> tensor<16x1x!FHE.esint<3>>
    %23 = "FHELinalg.reinterpret_precision"(%22) : (tensor<16x1x!FHE.esint<3>>) -> tensor<16x1x!FHE.esint<2>>
    %24 = "FHELinalg.lsb"(%23) : (tensor<16x1x!FHE.esint<2>>) -> tensor<16x1x!FHE.esint<2>>
    %25 = "FHELinalg.sub_eint"(%23, %24) : (tensor<16x1x!FHE.esint<2>>, tensor<16x1x!FHE.esint<2>>) -> tensor<16x1x!FHE.esint<2>>
    %26 = "FHELinalg.reinterpret_precision"(%25) : (tensor<16x1x!FHE.esint<2>>) -> tensor<16x1x!FHE.esint<8>>
    %27 = "FHELinalg.reinterpret_precision"(%26) : (tensor<16x1x!FHE.esint<8>>) -> tensor<16x1x!FHE.esint<1>>
    %cst_2 = arith.constant dense<[1, 0]> : tensor<2xi64>
    %28 = "FHELinalg.apply_lookup_table"(%27, %cst_2) : (tensor<16x1x!FHE.esint<1>>, tensor<2xi64>) -> tensor<16x1x!FHE.eint<4>>
    %expanded = tensor.expand_shape %28 [[0, 1], [2]] : tensor<16x1x!FHE.eint<4>> into tensor<2x8x1x!FHE.eint<4>>
    %cst_3 = arith.constant dense<"0x010101010000000001010107000000000101070001000000010107000700000001070000000000000700000000010101070000000001010707000000000107000700000000070000010101010000000001010107000000000101070001000000010107000700000001070000000000000700000000000000000000000000000000000000000000000000000000000000"> : tensor<2x9x8xi3>
    %29 = "FHELinalg.to_signed"(%expanded) : (tensor<2x8x1x!FHE.eint<4>>) -> tensor<2x8x1x!FHE.esint<4>>
    %30 = "FHELinalg.matmul_int_eint"(%cst_3, %29) : (tensor<2x9x8xi3>, tensor<2x8x1x!FHE.esint<4>>) -> tensor<2x9x1x!FHE.esint<4>>
    %collapsed = tensor.collapse_shape %30 [[0, 1], [2]] : tensor<2x9x1x!FHE.esint<4>> into tensor<18x1x!FHE.esint<4>>
    %cst_4 = arith.constant dense<[[4], [3], [3], [2], [1], [3], [2], [1], [0], [4], [3], [3], [2], [1], [0], [0], [0], [0]]> : tensor<18x1xi4>
    %cst_5 = arith.constant dense<[[0], [1], [1], [2], [3], [1], [2], [3], [4], [0], [1], [1], [2], [3], [4], [4], [4], [4]]> : tensor<18x1xindex>
    %cst_6 = arith.constant dense<[[0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], [0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], [0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], [0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]]> : tensor<5x16xi64>
    %31 = "FHELinalg.apply_mapped_lookup_table"(%collapsed, %cst_6, %cst_5) : (tensor<18x1x!FHE.esint<4>>, tensor<5x16xi64>, tensor<18x1xindex>) -> tensor<18x1x!FHE.eint<6>>
    %expanded_7 = tensor.expand_shape %31 [[0, 1], [2]] : tensor<18x1x!FHE.eint<6>> into tensor<2x9x1x!FHE.eint<6>>
    %cst_8 = arith.constant dense<[[[52, 63, 31, 61, 0, 6, 25, 63, 63], [11, 0, 32, 2, 63, 57, 38, 0, 0]], [[23, 0, 10, 63, 59, 0, 0, 0, 0], [40, 63, 53, 0, 4, 63, 0, 0, 0]]]> : tensor<2x2x9xi7>
    %32 = "FHELinalg.matmul_int_eint"(%cst_8, %expanded_7) : (tensor<2x2x9xi7>, tensor<2x9x1x!FHE.eint<6>>) -> tensor<2x2x1x!FHE.eint<6>>
    %33 = "FHELinalg.transpose"(%32) {axes = [2, 1, 0]} : (tensor<2x2x1x!FHE.eint<6>>) -> tensor<1x2x2x!FHE.eint<6>>
    return %33 : tensor<1x2x2x!FHE.eint<6>>
  }
}